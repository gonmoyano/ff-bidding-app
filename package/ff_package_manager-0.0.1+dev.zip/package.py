"""Package metadata."""

name = "ff_package_manager"
title = "FF Package Manager"
version = "0.0.1+dev"

client_dir = "ff_package_manager"

ayon_server_version = ">=1.0.0"
ayon_launcher_version = ">=1.0.0"

ayon_required_addons = {
    "core": ">=0.3.0",
}
